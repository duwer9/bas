<!DOCTYPE html>
<html>
<head>
    <title>BASDB</title>
</head>
<body>
    <h1>Boodschappendb</h1>
    <a href="klant/read_klant.php">Read klant</a><br>
    <a href="Verkooporder/read_verkooporder.php">Read verkooporder</a><br>
    <a href="artikel/read_artikel.php">Read artikel</a><br>
</body>
</html>
